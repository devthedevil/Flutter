package com.example.mp1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
